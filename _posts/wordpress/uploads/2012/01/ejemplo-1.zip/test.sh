source confirmar.sh

confirm Delete file1?
if [ $? -eq 0 ]
  then
   rm file1
fi
